Document Title:                 Acceptance Tests XML Export
Document Owner:                 AUTOSAR
Document Responsibility:        AUTOSAR
Document Identification Number: 845
Document Classification:        Auxiliary
Document Status:                Final
Part of AUTOSAR Standard:       Acceptance Tests for Classic Platform
Part of Standard Release:       1.2.0
Date:                           2016-12-15
